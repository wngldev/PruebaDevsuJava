package com.devsu.hackerearth.backend.account.controller;

import com.devsu.hackerearth.backend.account.handler.ResponseHandler;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.service.TransactionService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
public class TransactionController {

    private final TransactionService transactionService;

    @GetMapping
    public ResponseEntity<Object> getAll() {
        List<TransactionDto> transactions = transactionService.getAll();
        return ResponseHandler.generateResponse(HttpStatus.OK, transactions, true);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> get(@PathVariable Long id) {
        TransactionDto transaction = transactionService.getById(id);
        return ResponseHandler.generateResponse(HttpStatus.OK, transaction, true);
    }

    @GetMapping("/last/{accountId}")
    public ResponseEntity<Object> getLastByAccountId(@PathVariable Long accountId) {
        TransactionDto transaction = transactionService.getLastByAccountId(accountId);
        return ResponseHandler.generateResponse(HttpStatus.OK, transaction, true);
    }

    @PostMapping
    public ResponseEntity<Object> create(@Valid @RequestBody TransactionDto transactionDto) {
        TransactionDto createdTransaction = transactionService.create(transactionDto);
        return ResponseHandler.generateResponse(HttpStatus.CREATED, createdTransaction, true);
    }

    @GetMapping("/clients/{clientId}/report")
    public ResponseEntity<Object> report(@PathVariable Long clientId,
                                         @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateTransactionStart,
                                         @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date dateTransactionEnd) {
        List<BankStatementDto> report = transactionService.getAllByAccountClientIdAndDateBetween(clientId, dateTransactionStart, dateTransactionEnd);
        return ResponseHandler.generateResponse(HttpStatus.OK, report, true);
    }
}
