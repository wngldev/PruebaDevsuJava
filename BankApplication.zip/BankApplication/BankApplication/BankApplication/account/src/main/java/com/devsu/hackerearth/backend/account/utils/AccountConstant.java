package com.devsu.hackerearth.backend.account.utils;

public class AccountConstant {

    public static final String CLIENT_API_URL = "http://localhost:8001/api/clients/";

    public static final class ValidationMessages {
        public static final String NOT_BLANK_MESSAGE = "The name field should not be blank";

        private ValidationMessages() {
            throw new AssertionError("ValidationMessages class should not be instantiated.");
        }
    }

    private AccountConstant() {
        throw new AssertionError("AccountConstant class should not be instantiated.");
    }
}
