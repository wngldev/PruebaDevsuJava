package com.devsu.hackerearth.backend.account.model.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.devsu.hackerearth.backend.account.utils.AccountConstant;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AccountDto {


    private Long id;

	@NotNull
	@NotBlank(message = AccountConstant.ValidationMessages.NOT_BLANK_MESSAGE)
	private String number;

	@NotNull
	@NotBlank(message = AccountConstant.ValidationMessages.NOT_BLANK_MESSAGE)
	private String type;

	private double initialAmount;

	@NotNull
	private boolean isActive;

	@NotNull
	private Long clientId;
}
