package com.devsu.hackerearth.backend.client.controller;

import com.devsu.hackerearth.backend.client.handler.ResponseHandler;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.service.ClientService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/clients")
@RequiredArgsConstructor
public class ClientController {

	private final ClientService clientService;

	@GetMapping()
	public ResponseEntity<Object> getAll() {
		List<ClientDto> clients = clientService.getAll();
		return ResponseHandler.generateResponse(HttpStatus.OK, clients, true);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> get(@PathVariable Long id) {
		ClientDto client = clientService.getById(id);
		return ResponseHandler.generateResponse(HttpStatus.OK, client, true);
	}

	@PostMapping()
	public ResponseEntity<Object> create(@Valid @RequestBody ClientDto clientDto) {
		ClientDto createdClient = clientService.create(clientDto);
		return ResponseHandler.generateResponse(HttpStatus.CREATED, createdClient, true);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Object> update(@PathVariable Long id, @RequestBody ClientDto clientDto) {
		clientDto.setId(id);
		ClientDto updatedClient = clientService.update(clientDto);
		return ResponseHandler.generateResponse(HttpStatus.OK, updatedClient, true);
	}

	@PatchMapping("/{id}")
	public ResponseEntity<Object> partialUpdate(@Valid @PathVariable Long id,
			@Valid @RequestBody PartialClientDto partialClientDto) {
		ClientDto updatedClient = clientService.partialUpdate(id, partialClientDto);
		return ResponseHandler.generateResponse(HttpStatus.OK, updatedClient, true);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Object> delete(@PathVariable Long id) {
		clientService.deleteById(id);
		return ResponseHandler.generateResponse(HttpStatus.OK, "Se elimino correctamente", true);
	}
}
