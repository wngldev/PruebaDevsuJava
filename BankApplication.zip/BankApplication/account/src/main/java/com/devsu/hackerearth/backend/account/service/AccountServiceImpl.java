package com.devsu.hackerearth.backend.account.service;

import com.devsu.hackerearth.backend.account.converter.AccountConverter;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientResponseDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.service.AccountService;
import com.devsu.hackerearth.backend.account.utils.AccountConstant;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;
    private final AccountConverter accountConverter;
    private final RestTemplate restTemplate;

    public AccountServiceImpl(AccountRepository accountRepository, AccountConverter accountConverter,
            RestTemplate restTemplate) {
        this.accountRepository = accountRepository;
        this.accountConverter = accountConverter;
        this.restTemplate = restTemplate;
    }

    @Override
    public List<AccountDto> getAll() {
        try {
            return accountRepository.findAll().stream()
                    .map(accountConverter::toAccountDto)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            log.error("Error al obtener todas las cuentas: {}", e.getMessage());
            throw new RuntimeException("Error al obtener todas las cuentas", e);
        }
    }

    @Override
    public AccountDto getById(Long id) {
        try {
            return accountRepository.findById(id)
                    .map(accountConverter::toAccountDto)
                    .orElseThrow(() -> new EntityNotFoundException("Cuenta no encontrada con ID: " + id));
        } catch (EntityNotFoundException e) {
            log.error("Cuenta no encontrada con ID {}: {}", id, e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error inesperado al obtener la cuenta con ID {}: {}", id, e.getMessage());
            throw new RuntimeException("Error al obtener la cuenta", e);
        }
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        try {
            String clientUrl = AccountConstant.CLIENT_API_URL + accountDto.getClientId();
            log.info("Llamando a la API externa: {}", clientUrl);

            ResponseEntity<ClientResponseDto> response = restTemplate.exchange(
                    clientUrl,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<ClientResponseDto>() {
                    });

            ObjectMapper objectMapper = new ObjectMapper();
            String jsonResponse = objectMapper.writeValueAsString(response.getBody());
            log.info("Respuesta de la API [{}]: {}", response.getStatusCode(), jsonResponse);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null
                    && response.getBody().getData() != null) {

                Account account = accountConverter.toAccountEntity(accountDto);
                account.setBalance(accountDto.getInitialAmount());
                return accountConverter.toAccountDto(accountRepository.save(account));
            } else {
                log.warn("Cliente no encontrado con ID: {}", accountDto.getClientId());
                throw new EntityNotFoundException("Cliente no encontrado con ID: " + accountDto.getClientId());
            }
        } catch (HttpClientErrorException.NotFound e) {
            log.warn("Cliente no encontrado con ID {}: {}", accountDto.getClientId(), e.getMessage());
            throw new EntityNotFoundException("Cliente no encontrado con ID: " + accountDto.getClientId());
        } catch (EntityNotFoundException e) {
            log.error("Cuenta no encontrada con ID {}: {}", accountDto.getId(), e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error al crear la cuenta: {} - {}", e.getClass().getSimpleName(), e.getMessage(), e);
            throw new RuntimeException("Error al crear la cuenta", e);
        }
    }

    @Override
    public AccountDto update(AccountDto accountDto) {
        try {
            if (!accountRepository.existsById(accountDto.getId())) {
                log.warn("Cuenta no encontrada con ID: {}", accountDto.getId());
                throw new EntityNotFoundException("Cuenta no encontrada con ID: " + accountDto.getId());
            }

            String clientUrl = AccountConstant.CLIENT_API_URL + accountDto.getClientId();
            log.info("Verificando existencia del cliente en la API: {}", clientUrl);

            ResponseEntity<ClientResponseDto> response = restTemplate.exchange(
                    clientUrl,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<ClientResponseDto>() {
                    });

            ObjectMapper objectMapper = new ObjectMapper();
            String jsonResponse = objectMapper.writeValueAsString(response.getBody());
            log.info("Respuesta de la API [{}]: {}", response.getStatusCode(), jsonResponse);

            if (!(response.getStatusCode().is2xxSuccessful() && response.getBody() != null
                    && response.getBody().getData() != null)) {
                log.warn("Cliente no encontrado con ID: {}", accountDto.getClientId());
                throw new EntityNotFoundException("Cliente no encontrado con ID: " + accountDto.getClientId());
            }

            Account account = accountConverter.toAccountEntity(accountDto);
            return accountConverter.toAccountDto(accountRepository.save(account));

        } catch (HttpClientErrorException.NotFound e) {
            log.warn("Cliente no encontrado con ID: {}", accountDto.getClientId());
            throw new EntityNotFoundException("Cliente no encontrado con ID: " + accountDto.getClientId());
        } catch (EntityNotFoundException e) {
            log.error("Error al actualizar la cuenta: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error inesperado al actualizar la cuenta: {}", e.getMessage(), e);
            throw new RuntimeException("Error al actualizar la cuenta", e);
        }
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        try {
            Account existingAccount = accountRepository.findById(id)
                    .orElseThrow(() -> new EntityNotFoundException("Cuenta no encontrada con ID: " + id));

            existingAccount.setActive(partialAccountDto.getIsActive());

            return accountConverter.toAccountDto(accountRepository.save(existingAccount));
        } catch (EntityNotFoundException e) {
            log.error("Cuenta no encontrada al intentar actualización parcial: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error inesperado al actualizar parcialmente la cuenta con ID {}: {}", id, e.getMessage());
            throw new RuntimeException("Error al actualizar parcialmente la cuenta", e);
        }
    }

    @Override
    public void deleteById(Long id) {
        try {
            if (!accountRepository.existsById(id)) {
                throw new EntityNotFoundException("Cuenta no encontrada con ID: " + id);
            }
            accountRepository.deleteById(id);
        } catch (EntityNotFoundException e) {
            log.error("Cuenta no encontrada al intentar eliminar: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error inesperado al eliminar la cuenta con ID {}: {}", id, e.getMessage());
            throw new RuntimeException("Error al eliminar la cuenta", e);
        }
    }
}
