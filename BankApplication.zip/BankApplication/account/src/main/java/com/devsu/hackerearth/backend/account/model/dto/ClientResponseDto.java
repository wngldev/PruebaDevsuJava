package com.devsu.hackerearth.backend.account.model.dto;

import lombok.Data;

@Data
public class ClientResponseDto {
    private ClientDataDto data;
    private String timestamp;
    private int status;
}

