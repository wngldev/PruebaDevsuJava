package com.devsu.hackerearth.backend.account.model.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.devsu.hackerearth.backend.account.utils.AccountConstant;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AccountDto {

	public AccountDto(long l, String string, String string2, double d, boolean b) {
        //TODO Auto-generated constructor stub
    }

    private Long id;

	@NotNull
	@NotBlank(message = AccountConstant.ValidationMessages.NOT_BLANK_MESSAGE)
	private String number;

	@NotNull
	@NotBlank(message = AccountConstant.ValidationMessages.NOT_BLANK_MESSAGE)
	private String type;

	private double initialAmount;

	@NotNull
	private boolean isActive;

	@NotNull
	private Long clientId;
}
