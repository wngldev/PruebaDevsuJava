package com.devsu.hackerearth.backend.account.controller;

import com.devsu.hackerearth.backend.account.handler.ResponseHandler;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.service.AccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/accounts")
@RequiredArgsConstructor
public class AccountController {

	private final AccountService accountService;

	@GetMapping
	public ResponseEntity<Object> getAll() {
		List<AccountDto> accounts = accountService.getAll();
		return ResponseHandler.generateResponse(HttpStatus.OK, accounts, true);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> get(@PathVariable Long id) {
		AccountDto account = accountService.getById(id);
		return ResponseHandler.generateResponse(HttpStatus.OK, account, true);
	}

	@PostMapping
	public ResponseEntity<Object> create(@Valid @RequestBody AccountDto accountDto) {
		AccountDto createdAccount = accountService.create(accountDto);
		return ResponseHandler.generateResponse(HttpStatus.CREATED, createdAccount, true);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Object> update(@PathVariable Long id, @RequestBody AccountDto accountDto) {
		accountDto.setId(id);
		AccountDto updatedAccount = accountService.update(accountDto);
		return ResponseHandler.generateResponse(HttpStatus.OK, updatedAccount, true);
	}

	@PatchMapping("/{id}")
	public ResponseEntity<Object> partialUpdate(@Valid @PathVariable Long id,
			@Valid @RequestBody PartialAccountDto partialAccountDto) {
		AccountDto updatedAccount = accountService.partialUpdate(id, partialAccountDto);
		return ResponseHandler.generateResponse(HttpStatus.OK, updatedAccount, true);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Object> delete(@PathVariable Long id) {
		accountService.deleteById(id);
		return ResponseHandler.generateResponse(HttpStatus.OK, "Se eliminó correctamente", true);
	}
}
