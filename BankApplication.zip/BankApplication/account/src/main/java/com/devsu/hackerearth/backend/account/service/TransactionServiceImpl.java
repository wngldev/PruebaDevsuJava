package com.devsu.hackerearth.backend.account.service;

import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;
import com.devsu.hackerearth.backend.account.utils.AccountConstant;
import com.devsu.hackerearth.backend.account.converter.TransactionConverter;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.ClientResponseDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import javax.persistence.EntityNotFoundException;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final TransactionConverter transactionConverter;
    private final AccountRepository accountRepository;
    private final RestTemplate restTemplate;

    public TransactionServiceImpl(TransactionRepository transactionRepository,
            TransactionConverter transactionConverter,
            AccountRepository accountRepository, RestTemplate restTemplate) {
        this.transactionRepository = transactionRepository;
        this.transactionConverter = transactionConverter;
        this.accountRepository = accountRepository;
        this.restTemplate = restTemplate;
    }

    @Override
    public List<TransactionDto> getAll() {
        try {
            return transactionRepository.findAll().stream()
                    .map(transactionConverter::toTransactionDto)
                    .collect(Collectors.toList());
        } catch (Exception e) {
            log.error("Error al obtener todas las transacciones: {}", e.getMessage());
            throw new RuntimeException("Error al obtener todas las transacciones", e);
        }
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        try {
            log.info("Iniciando registro de transacción para la cuenta ID: {}", transactionDto.getAccountId());

            Account account = accountRepository.findById(transactionDto.getAccountId())
                    .orElseThrow(() -> new EntityNotFoundException(
                            "Cuenta no encontrada con ID: " + transactionDto.getAccountId()));

            log.info("Cuenta encontrada. Saldo actual: {}", account.getBalance());

            double nuevoSaldo;
            if ("DEPOSITO".equalsIgnoreCase(transactionDto.getType())) {
                nuevoSaldo = account.getBalance() + transactionDto.getAmount();
                log.info("Depósito de {} realizado. Nuevo saldo: {}", transactionDto.getAmount(), nuevoSaldo);
            } else if ("RETIRO".equalsIgnoreCase(transactionDto.getType())) {
                nuevoSaldo = account.getBalance() - transactionDto.getAmount();
                if (nuevoSaldo < 0) {
                    log.warn("Saldo insuficiente para la cuenta ID: {}", account.getId());
                    throw new IllegalArgumentException("Saldo no disponible");
                }
                log.info("Retiro de {} realizado. Nuevo saldo: {}", transactionDto.getAmount(), nuevoSaldo);
            } else {
                log.warn("Tipo de transacción no válido: {}", transactionDto.getType());
                throw new IllegalArgumentException("Tipo de transacción no válido, escoger entre DEPOSITO o RETIRO");
            }

            account.setBalance(nuevoSaldo);
            accountRepository.save(account);
            log.info("Saldo actualizado en la cuenta ID: {}", account.getId());

            Transaction transaction = transactionConverter.toTransactionEntity(transactionDto);
            transaction.setBalance(nuevoSaldo);
            transaction = transactionRepository.save(transaction);
            log.info("Transacción registrada con éxito. ID: {}", transaction.getId());

            return transactionConverter.toTransactionDto(transaction);
        } catch (EntityNotFoundException e) {
            log.error("Error al registrar la transacción: {}", e.getMessage());
            throw e;
        } catch (IllegalArgumentException e) {
            log.warn("Operación rechazada: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("Error inesperado al registrar la transacción: {}", e.getMessage());
            throw new RuntimeException("Error al registrar la transacción", e);
        }
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long accountId, Date startDate, Date endDate) {
        Account account = accountRepository.findById(accountId)
                .orElseThrow(() -> new EntityNotFoundException(
                        "Cuenta no encontrada para ID: " + accountId));
        String clientUrl = AccountConstant.CLIENT_API_URL + account.getId();
        log.info("Consultando cliente en API externa: {}", account.getId());

        String clientName;
        try {
            ResponseEntity<ClientResponseDto> response = restTemplate.exchange(
                    clientUrl,
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<ClientResponseDto>() {
                    });

            ObjectMapper objectMapper = new ObjectMapper();
            String jsonResponse = objectMapper.writeValueAsString(response.getBody());
            log.info("Respuesta API [{}]: {}", response.getStatusCode(), jsonResponse);

            if (response.getStatusCode().is2xxSuccessful() && response.getBody() != null
                    && response.getBody().getData() != null) {
                clientName = response.getBody().getData().getName();
            } else {
                throw new EntityNotFoundException("Cliente no encontrado con ID: " + account.getId());
            }
        } catch (HttpClientErrorException.NotFound e) {
            log.warn("Cliente no encontrado: {}", e.getMessage());
            throw new EntityNotFoundException("Cliente no encontrado con ID: " + account.getId());
        } catch (Exception e) {
            log.error("Error obteniendo cliente: {}", e.getMessage(), e);
            throw new RuntimeException("Error obteniendo cliente", e);
        }

        List<Transaction> transactions = transactionRepository.findByAccountIdAndDateBetween(accountId, startDate, endDate);

        log.info("Se encontraron {} transacciones para el accountId ID: {}", transactions.size(), accountId);

        return transactions.stream()
                .map(transaction -> new BankStatementDto(
                        transaction.getDate(),
                        clientName,
                        account.getNumber(),
                        account.getType(),
                        account.getInitialAmount(),
                        account.isActive(),
                        transaction.getType(),
                        transaction.getAmount(),
                        transaction.getBalance()))
                .collect(Collectors.toList());
    }


    @Override
    public TransactionDto getById(Long id) {
        return transactionRepository.findById(id)
                .map(transactionConverter::toTransactionDto)
                .orElseThrow(() -> new EntityNotFoundException("Transacción no encontrada con ID: " + id));
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        Transaction transaction = transactionRepository.findTopByAccountIdOrderByDateDesc(accountId)
                .orElseThrow(() -> new EntityNotFoundException("No se encontraron transacciones para la cuenta ID: " + accountId));
        return transactionConverter.toTransactionDto(transaction);
    }
}
