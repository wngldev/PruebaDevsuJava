package com.devsu.hackerearth.backend.account.exception.core;

public class ApiSubError {
    
}
