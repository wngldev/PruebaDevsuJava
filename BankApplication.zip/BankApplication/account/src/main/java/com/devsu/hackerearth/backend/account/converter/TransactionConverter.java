package com.devsu.hackerearth.backend.account.converter;

import org.springframework.stereotype.Component;

import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;

@Component
public class TransactionConverter {

    public TransactionDto toTransactionDto(Transaction entity) {
        return new TransactionDto(
                entity.getId(),
                entity.getDate(),
                entity.getType(),
                entity.getAmount(),
                entity.getAccountId());
    }

    public Transaction toTransactionEntity(TransactionDto dto) {
        Transaction entity = new Transaction();
        entity.setId(dto.getId());
        entity.setDate(dto.getDate());
        entity.setType(dto.getType());
        entity.setAmount(dto.getAmount());
        entity.setAccountId(dto.getAccountId());
        return entity;
    }
}