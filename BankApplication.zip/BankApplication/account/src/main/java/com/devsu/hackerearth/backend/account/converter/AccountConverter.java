package com.devsu.hackerearth.backend.account.converter;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import org.springframework.stereotype.Component;

@Component
public class AccountConverter {

    public AccountDto toAccountDto(Account entity) {
        return new AccountDto(
                entity.getId(),
                entity.getNumber(),
                entity.getType(),
                entity.getInitialAmount(),
                entity.isActive(),
                entity.getClientId());
    }

    public Account toAccountEntity(AccountDto dto) {
        Account entity = new Account();
        entity.setId(dto.getId());
        entity.setNumber(dto.getNumber());
        entity.setType(dto.getType());
        entity.setInitialAmount(dto.getInitialAmount());
        entity.setActive(dto.isActive());
        entity.setClientId(dto.getClientId());
        return entity;
    }
}