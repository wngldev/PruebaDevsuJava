package com.devsu.hackerearth.backend.client.exception.core;

public class ApiSubError {
    
}
