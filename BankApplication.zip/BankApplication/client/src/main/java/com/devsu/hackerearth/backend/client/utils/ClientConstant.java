package com.devsu.hackerearth.backend.client.utils;

public class ClientConstant {

    public static final class ValidationMessages {
        public static final String NOT_BLANK_MESSAGE = "The name field should not be blank";



        private ValidationMessages() {
            throw new AssertionError("ValidationMessages class should not be instantiated.");
        }
    }
    
}
