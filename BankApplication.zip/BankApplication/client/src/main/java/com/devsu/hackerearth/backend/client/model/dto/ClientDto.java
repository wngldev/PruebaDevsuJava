package com.devsu.hackerearth.backend.client.model.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.devsu.hackerearth.backend.client.utils.ClientConstant;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ClientDto {

	private Long id;

	@NotNull
    @NotBlank(message = ClientConstant.ValidationMessages.NOT_BLANK_MESSAGE)
	private String dni;

	@NotNull
    @NotBlank(message = ClientConstant.ValidationMessages.NOT_BLANK_MESSAGE)
	private String name;

	private String password;
	private String gender;
	private int age;
	private String address;
	private String phone;
	private boolean isActive;
}
