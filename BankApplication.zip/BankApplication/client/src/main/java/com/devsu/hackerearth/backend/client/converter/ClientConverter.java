package com.devsu.hackerearth.backend.client.converter;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import org.springframework.stereotype.Component;

@Component
public class ClientConverter {

    public ClientConverter() {
    }

    public ClientDto toClientDto(Client entity) {
        return new ClientDto(
                entity.getId(),
                entity.getDni(),
                entity.getName(),
                entity.getPassword(),
                entity.getGender(),
                entity.getAge(),
                entity.getAddress(),
                entity.getPhone(),
                entity.isActive());
    }

    public Client toClientEntity(ClientDto dto) {
        Client entity = new Client();
        entity.setId(dto.getId());
        entity.setDni(dto.getDni());
        entity.setName(dto.getName());
        entity.setPassword(dto.getPassword());
        entity.setGender(dto.getGender());
        entity.setAge(dto.getAge());
        entity.setAddress(dto.getAddress());
        entity.setPhone(dto.getPhone());
        entity.setActive(dto.isActive());
        return entity;
    }
}