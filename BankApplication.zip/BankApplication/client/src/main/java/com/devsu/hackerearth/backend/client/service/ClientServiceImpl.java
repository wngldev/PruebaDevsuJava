package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.client.converter.ClientConverter;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;
	private final ClientConverter clientConverter;

	@Override
	public List<ClientDto> getAll() {
		try {
			return clientRepository.findAll().stream()
					.map(clientConverter::toClientDto)
					.collect(Collectors.toList());
		} catch (Exception e) {
			log.error("Error al obtener todos los clientes: {}", e.getMessage());
			throw new RuntimeException("Error al obtener todos los clientes", e);
		}
	}

	@Override
	public ClientDto getById(Long id) {
		try {
			return clientRepository.findById(id)
					.map(clientConverter::toClientDto)
					.orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con id: " + id));
		} catch (EntityNotFoundException e) {
			log.error("Cliente no encontrado con id {}: {}", id, e.getMessage());
			throw e;
		} catch (Exception e) {
			log.error("Error inesperado al obtener el cliente con id {}: {}", id, e.getMessage());
			throw new RuntimeException("Error al obtener el cliente", e);
		}
	}

	@Override
	@Transactional
	public ClientDto create(ClientDto clientDto) {
		try {
			Client client = clientConverter.toClientEntity(clientDto);
			return clientConverter.toClientDto(clientRepository.save(client));
		} catch (Exception e) {
			log.error("Error al crear el cliente: {}", e.getMessage());
			throw new RuntimeException("Error al crear el cliente", e);
		}
	}

	@Override
	@Transactional
	public ClientDto update(ClientDto clientDto) {
		try {
			if (!clientRepository.existsById(clientDto.getId())) {
				throw new EntityNotFoundException("Cliente no encontrado con id: " + clientDto.getId());
			}
			Client client = clientConverter.toClientEntity(clientDto);
			return clientConverter.toClientDto(clientRepository.save(client));
		} catch (EntityNotFoundException e) {
			log.error("Cliente no encontrado al intentar actualizar: {}", e.getMessage());
			throw e;
		} catch (Exception e) {
			log.error("Error inesperado al actualizar el cliente: {}", e.getMessage());
			throw new RuntimeException("Error al actualizar el cliente", e);
		}
	}

	@Override
	@Transactional
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		try {
			Client client = clientRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("Cliente no encontrado con id: " + id));

			client.setActive(partialClientDto.getIsActive());

			return clientConverter.toClientDto(clientRepository.save(client));
		} catch (EntityNotFoundException e) {
			log.error("Cliente no encontrado al intentar actualización parcial: {}", e.getMessage());
			throw e;
		} catch (Exception e) {
			log.error("Error inesperado al actualizar parcialmente el cliente con id {}: {}", id, e.getMessage());
			throw new RuntimeException("Error al actualizar parcialmente el cliente", e);
		}
	}

	@Override
	@Transactional
	public void deleteById(Long id) {
		try {
			if (!clientRepository.existsById(id)) {
				throw new EntityNotFoundException("Cliente no encontrado con id: " + id);
			}
			clientRepository.deleteById(id);
		} catch (EntityNotFoundException e) {
			log.error("Cliente no encontrado al intentar eliminar: {}", e.getMessage());
			throw e;
		} catch (Exception e) {
			log.error("Error inesperado al eliminar el cliente con id {}: {}", id, e.getMessage());
			throw new RuntimeException("Error al eliminar el cliente", e);
		}
	}
}
