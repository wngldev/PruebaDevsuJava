package com.devsu.hackerearth.backend.client.model;

import javax.persistence.Entity;

import lombok.Data;

@Entity
@Data
public class Client extends Person {
	public Client(Long id, String dni, String name, String password2, String gender, int age, String address,
            String phone, boolean active) {
        //TODO Auto-generated constructor stub
    }
    public Client() {
        //TODO Auto-generated constructor stub
    }
    private String password;
	private boolean isActive;
}
