package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.devsu.hackerearth.backend.client.model.Client;

@SpringBootTest
class ClientApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void givenValidData_whenCreateClient_thenSuccess() {
		Long id = 1L;
		String dni = "Dni123";
		String name = "John Doe";
		String password = "password123";
		String gender = "Male";
		int age = 30;
		String address = "123 Main St";
		String phone = "1234567890";
		boolean active = true;

		Client client = new Client(id, dni, name, password, gender, age, address, phone, active);

		assertEquals(id, client.getId());
		assertEquals(dni, client.getDni());
		assertEquals(name, client.getName());
		assertEquals(password, client.getPassword());
		assertEquals(gender, client.getGender());
		assertEquals(age, client.getAge());
		assertEquals(address, client.getAddress());
		assertEquals(phone, client.getPhone());
		assertEquals(active, client.isActive());
	}

}
